<?php @session_start(); ?>
<div>
    <?php \Assest\Assest::loadJavaScript('Js');
    \Assest\Assest::loadJavaScript('assets/bootstrap/js'); ?>
</div>
