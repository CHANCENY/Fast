<?php @session_start(); ?>
<div class="w-100 pt-3 pb-3 ps-5 border-bottom shadow bg-white text-dark fs-3">
    <?php echo $name; ?>
</div>
