<?php @session_start(); 
\Core\Router::attachView('heros',['name'=>"About page"]);
?>