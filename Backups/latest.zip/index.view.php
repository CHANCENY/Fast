<?php @session_start();

\Core\Router::attachView('heros',['name'=>"Home page"]);
?>
